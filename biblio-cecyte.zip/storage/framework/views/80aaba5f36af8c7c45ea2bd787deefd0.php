<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Libro - Biblioteca CECyTE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }
        .edit-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .edit-header {
            background: linear-gradient(45deg, #f39c12, #e67e22);
            color: white;
            border-radius: 15px 15px 0 0;
        }
        .file-preview {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
            border-left: 4px solid #f39c12;
        }
        .form-control:focus, .form-select:focus {
            border-color: #f39c12;
            box-shadow: 0 0 0 0.2rem rgba(243, 156, 18, 0.25);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand nav-brand" href="<?php echo e(route('dashboard')); ?>">
                <i class="fas fa-book"></i> Biblioteca CECyTE
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="<?php echo e(route('profile.show')); ?>">Mi Perfil</a>
                <?php if(Auth::user()->isAdmin()): ?>
                    <a class="nav-link" href="<?php echo e(route('admin.usuarios.index')); ?>">
                        <i class="fas fa-users-cog"></i> Administración
                    </a>
                <?php endif; ?>
                <?php if(Auth::user()->tipo_usuario === 'Docente'): ?>
                    <a class="nav-link" href="<?php echo e(route('docente.libros.index')); ?>">
                        <i class="fas fa-book"></i> Mis Libros
                    </a>
                <?php endif; ?>
                <a class="nav-link" href="<?php echo e(route('favoritos.index')); ?>">
                    <i class="fas fa-star"></i> Mis Favoritos
                </a>
                <span class="navbar-text me-3">
                    Bienvenido/a, <?php echo e(Auth::user()->nombre); ?>

                </span>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-light btn-sm">Cerrar Sesión</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card edit-card">
            <div class="card-header edit-header py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="fas fa-edit"></i> Editar Libro: <?php echo e($libro->titulo); ?>

                    </h4>
                    <a href="<?php echo e(route('docente.libros.index')); ?>" class="btn btn-light">
                        <i class="fas fa-arrow-left"></i> Volver
                    </a>
                </div>
            </div>
            <div class="card-body p-4">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Información del Archivo Actual -->
                <div class="file-preview mb-4">
                    <h6 class="text-warning mb-3">
                        <i class="fas fa-file-pdf"></i> Archivo Actual
                    </h6>
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <i class="fas fa-file-pdf text-danger fa-2x"></i>
                            <div class="ms-3 d-inline-block">
                                <strong><?php echo e($libro->nombre_archivo); ?></strong>
                                <br>
                                <small class="text-muted">
                                    Tamaño: <?php echo e($libro->getTamanioFormateado()); ?> • 
                                    Subido: <?php echo e($libro->created_at->format('d/m/Y H:i')); ?>

                                </small>
                            </div>
                        </div>
                        <div>
                            <a href="<?php echo e(route('docente.libros.download', $libro->id)); ?>" 
                               class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-download"></i> Descargar
                            </a>
                        </div>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <i class="fas fa-info-circle"></i>
                            El archivo PDF no se puede modificar. Si necesitas cambiar el archivo, 
                            elimina este libro y crea uno nuevo.
                        </small>
                    </div>
                </div>

                <form method="POST" action="<?php echo e(route('docente.libros.update', $libro->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <h5 class="text-primary mb-3">
                        <i class="fas fa-info-circle"></i> Información del Libro
                    </h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="titulo" class="form-label">Título del Libro *</label>
                            <input type="text" class="form-control" id="titulo" name="titulo" 
                                   value="<?php echo e(old('titulo', $libro->titulo)); ?>" required maxlength="255">
                        </div>
                        
                        <div class="col-md-6">
                            <label for="autor" class="form-label">Autor(es) *</label>
                            <input type="text" class="form-control" id="autor" name="autor" 
                                   value="<?php echo e(old('autor', $libro->autor)); ?>" required maxlength="255">
                        </div>
                        
                        <div class="col-md-4">
                            <label for="anio_publicacion" class="form-label">Año de Publicación *</label>
                            <input type="number" class="form-control" id="anio_publicacion" name="anio_publicacion" 
                                   value="<?php echo e(old('anio_publicacion', $libro->anio_publicacion)); ?>" 
                                   min="1900" max="<?php echo e(date('Y') + 1); ?>" required>
                        </div>
                        
                        <div class="col-md-4">
                            <label for="isbn" class="form-label">ISBN (Opcional)</label>
                            <input type="text" class="form-control" id="isbn" name="isbn" 
                                   value="<?php echo e(old('isbn', $libro->isbn)); ?>" maxlength="20">
                        </div>
                        
                        <div class="col-md-4">
                            <label for="materia" class="form-label">Materia *</label>
                            <input type="text" class="form-control" id="materia" name="materia" 
                                   value="<?php echo e(old('materia', $libro->materia)); ?>" required maxlength="150">
                        </div>
                        
                        <div class="col-md-6">
                            <label for="carrera" class="form-label">Carrera *</label>
                            <select class="form-select" id="carrera" name="carrera" required>
                                <option value="">Selecciona una carrera</option>
                                <option value="Soporte y Mantenimiento de Equipo de Cómputo" 
                                    <?php echo e((old('carrera', $libro->carrera) == 'Soporte y Mantenimiento de Equipo de Cómputo') ? 'selected' : ''); ?>>
                                    Soporte y Mantenimiento de Equipo de Cómputo
                                </option>
                                <option value="Enfermería General" 
                                    <?php echo e((old('carrera', $libro->carrera) == 'Enfermería General') ? 'selected' : ''); ?>>
                                    Enfermería General
                                </option>
                                <option value="Ventas" 
                                    <?php echo e((old('carrera', $libro->carrera) == 'Ventas') ? 'selected' : ''); ?>>
                                    Ventas
                                </option>
                                <option value="Diseño Gráfico Digital" 
                                    <?php echo e((old('carrera', $libro->carrera) == 'Diseño Gráfico Digital') ? 'selected' : ''); ?>>
                                    Diseño Gráfico Digital
                                </option>
                            </select>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="semestre" class="form-label">Semestre *</label>
                            <select class="form-select" id="semestre" name="semestre" required>
                                <option value="">Selecciona un semestre</option>
                                <option value="1°" <?php echo e((old('semestre', $libro->semestre) == '1°') ? 'selected' : ''); ?>>1° Semestre</option>
                                <option value="2°" <?php echo e((old('semestre', $libro->semestre) == '2°') ? 'selected' : ''); ?>>2° Semestre</option>
                                <option value="3°" <?php echo e((old('semestre', $libro->semestre) == '3°') ? 'selected' : ''); ?>>3° Semestre</option>
                                <option value="4°" <?php echo e((old('semestre', $libro->semestre) == '4°') ? 'selected' : ''); ?>>4° Semestre</option>
                                <option value="5°" <?php echo e((old('semestre', $libro->semestre) == '5°') ? 'selected' : ''); ?>>5° Semestre</option>
                                <option value="6°" <?php echo e((old('semestre', $libro->semestre) == '6°') ? 'selected' : ''); ?>>6° Semestre</option>
                            </select>
                        </div>
                        
                        <div class="col-12">
                            <label for="descripcion" class="form-label">Descripción (Opcional)</label>
                            <textarea class="form-control" id="descripcion" name="descripcion" 
                                      rows="3" maxlength="500"><?php echo e(old('descripcion', $libro->descripcion)); ?></textarea>
                            <div class="form-text">
                                Breve descripción o resumen del contenido del libro (máximo 500 caracteres).
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="descargable" name="descargable" value="1" 
                                    <?php echo e($libro->descargable ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="descargable">
                                    Permitir descarga del archivo PDF por parte de los alumnos
                                </label>
                            </div>
                            <div class="form-text">
                                Si esta opción está desactivada, los alumnos solo podrán visualizar el libro en línea.
                            </div>
                        </div>
                    </div>

                    <!-- Estadísticas -->
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="alert alert-info">
                                <h6 class="alert-heading">
                                    <i class="fas fa-chart-bar"></i> Estadísticas del Libro
                                </h6>
                                <div class="row text-center">
                                    <div class="col-md-4">
                                        <strong><?php echo e($libro->veces_descargado); ?></strong>
                                        <br>
                                        <small>Descargas</small>
                                    </div>
                                    <div class="col-md-4">
                                        <strong><?php echo e($libro->veces_visto); ?></strong>
                                        <br>
                                        <small>Visualizaciones</small>
                                    </div>
                                    <div class="col-md-4">
                                        <strong><?php echo e($libro->created_at->diffForHumans()); ?></strong>
                                        <br>
                                        <small>En la biblioteca</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Botones de Acción -->
                    <div class="d-flex gap-2 justify-content-end mt-4">
                        <a href="<?php echo e(route('docente.libros.index')); ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-times"></i> Cancelar
                        </a>
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-save"></i> Guardar Cambios
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\biblio-cecyte\resources\views/docente/libros/edit.blade.php ENDPATH**/ ?>