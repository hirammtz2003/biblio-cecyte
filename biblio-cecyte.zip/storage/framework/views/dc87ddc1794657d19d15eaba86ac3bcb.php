<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - Biblioteca CECyTE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }
        .profile-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .profile-header {
            background: linear-gradient(45deg, #db8008ff, #a06b08ff);
            color: white;
            border-radius: 15px 15px 0 0;
        }
        .info-label {
            font-weight: 600;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand nav-brand" href="<?php echo e(route('dashboard')); ?>">
                <i class="fas fa-book"></i> Biblioteca CECyTE
            </a>
            <div class="navbar-nav ms-auto">
                <?php if(Auth::user()->isAdmin()): ?>
                    <a class="nav-link" href="<?php echo e(route('admin.usuarios.index')); ?>">
                        <i class="fas fa-users-cog"></i> Administración de Usuarios
                    </a>
                <?php endif; ?>
                <?php if(Auth::user()->tipo_usuario === 'Docente'): ?>
                    <a class="nav-link" href="<?php echo e(route('docente.libros.index')); ?>">
                        <i class="fas fa-book"></i> Mis Libros
                    </a>
                <?php endif; ?>
                <?php if(Auth::user()->tipo_usuario === 'Administrador'): ?>
                    <a class="nav-link" href="<?php echo e(route('admin.libros.index')); ?>">
                        <i class="fas fa-book"></i> Mis Libros
                    </a>
                <?php endif; ?>
                <a class="nav-link" href="<?php echo e(route('favoritos.index')); ?>">
                    <i class="fas fa-star"></i> Mis Favoritos
                </a>
                <span class="navbar-text me-3">
                    Bienvenido/a, <?php echo e(Auth::user()->nombre); ?>

                </span>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-light btn-sm">Cerrar Sesión</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card profile-card">
                    <div class="card-header profile-header py-3">
                        <h4 class="mb-0">Mi Perfil</h4>
                    </div>
                    <div class="card-body p-4">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <div class="row mb-3">
                            <div class="col-md-4 info-label">Nombre completo:</div>
                            <div class="col-md-8"><?php echo e($usuario->getNombreCompleto()); ?></div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4 info-label">Número de control:</div>
                            <div class="col-md-8"><?php echo e($usuario->numero_control); ?></div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4 info-label">Carrera:</div>
                            <div class="col-md-8"><?php echo e($usuario->carrera); ?></div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4 info-label">Email:</div>
                            <div class="col-md-8"><?php echo e($usuario->email); ?></div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4 info-label">Tipo de usuario:</div>
                            <div class="col-md-8">
                                <span class="badge bg-<?php echo e($usuario->isAdmin() ? 'danger' : 'primary'); ?>">
                                    <?php echo e($usuario->tipo_usuario); ?>

                                </span>
                            </div>
                        </div>

                        <div class="d-flex gap-2 mt-4">
                            <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary">
                                Editar Perfil
                            </a>
                            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-secondary">
                                Volver al Dashboard
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\biblio-cecyte\resources\views/profile/show.blade.php ENDPATH**/ ?>